import time
import random
import string
import matplotlib.pyplot as plt

# ===== BST Node and BST Class =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            # Node with one or no children
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            # Node with two children
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

# ===== AVL Node and AVL Tree Class =====

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        # Rotations
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Balancing
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

# ===== RBT Node and RBT Class =====

class RedBlackNode:
    """Represents a node in a Red-Black Tree."""
    def __init__(self, name, phone=None, color="RED"):
        self.name = name
        self.phone = phone
        self.color = color  # RED or BLACK
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    """Implements a Red-Black Tree with balancing after insertions and deletions."""
    
    def __init__(self):
        self.NIL = RedBlackNode(None, None, "BLACK")  # Sentinel NIL node
        self.root = self.NIL  # Root of the tree

    def insert(self, name, phone):
        """Inserts a new key into the Red-Black Tree and balances it."""
        new_node = RedBlackNode(name, phone)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.name < current.name:
                current = current.left
            else:
                current = current.right

        new_node.parent = parent

        if parent is None:  # Tree was empty
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "RED"  # New nodes are always inserted as RED
        self._fix_insert(new_node)  # Balance the tree

    def _fix_insert(self, node):
        """Fixes the Red-Black Tree after an insertion to maintain balance."""
        while node.parent and node.parent.color == "RED":
            grandparent = node.parent.parent

            if node.parent == grandparent.left:  # Parent is a left child
                uncle = grandparent.right

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.right:  # Case 2: Left-Right → Rotate Left
                        node = node.parent
                        self._rotate_left(node)

                    # Case 3: Left-Left → Rotate Right
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_right(grandparent)

            else:  # Parent is a right child (Mirror cases)
                uncle = grandparent.left

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.left:  # Case 2: Right-Left → Rotate Right
                        node = node.parent
                        self._rotate_right(node)

                    # Case 3: Right-Right → Rotate Left
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_left(grandparent)

        self.root.color = "BLACK"  # Ensure root is always BLACK

    def search(self, name):
        """Searches for a key in the Red-Black Tree."""
        current = self.root
        while current != self.NIL:
            if name == current.name:
                return current  # Node found
            elif name < current.name:
                current = current.left
            else:
                current = current.right
        return None  # Not found

    def delete(self, name):
        current = self.root
        while current != self.NIL:
            if name > current.name:
                current = current.right
            elif name < current.name:
                current = current.left
            else: # Node found
                check_color = current.color
                if current.left == self.NIL: # No left child
                    node_new = current.right
                    self._transplant(current, current.right)
                elif current.right == self.NIL: # No right child
                    node_new = current.left
                    self._transplant(current, current.left)
                else: # Have both children
                    temp = self._find_min(current.right)
                    check_color = temp.color
                    node_new = temp.right
                    if temp.parent == current:
                        node_new.parent = temp
                    else:
                        self._transplant(temp, temp.right)
                        temp.right = current.right
                        temp.right.parent = temp
                    self._transplant(current, temp)
                    temp.left = current.left
                    temp.left.parent = temp
                    temp.color = current.color
                if check_color == "BLACK":
                    self._fix_delete(node_new)
                return current
        return None

    def _find_min(self, root):
        current = root
        while current.left != self.NIL:
            current = current.left
        return current
        
    def _transplant(self, node, node_new):
        # Replace the Node (node) with New Node (node_new)
        if node.parent is None:
            self.root = node_new
        elif node == node.parent.left:
            node.parent.left = node_new
        else:
            node.parent.right = node_new
        node_new.parent = node.parent

    def _fix_delete(self, node):
        while node != self.root and node.color == "BLACK":
            if node == node.parent.left:
                sibling = node.parent.right
                # Case 1: sibling is RED
                if sibling.color == "RED":
                    sibling.color = "BLACK"
                    node.parent.color = "RED"
                    self._rotate_left(node.parent)
                    sibling = node.parent.right
                # Case 2: sibling is BLACK, and both sibling's children are BLACK
                if sibling.left.color == "BLACK" and sibling.right.color == "BLACK":
                    sibling.color = "RED"
                    node = node.parent
                else:
                    # Case 3: sibling is BLACK, sibling's right is BLACK, left is RED
                    if sibling.right.color == "BLACK":
                        sibling.left.color = "BLACK"
                        sibling.color = "RED"
                        self._rotate_right(sibling)
                        sibling = node.parent.right

                    # Case 4: sibling is BLACK, sibling's right is RED
                    sibling.color = node.parent.color
                    node.parent.color = "BLACK"
                    sibling.right.color = "BLACK"
                    self._rotate_left(node.parent)
                    node = self.root
            else:
                sibling = node.parent.left
                # Mirror Case 1: sibling is RED
                if sibling.color == "RED":
                    sibling.color = "BLACK"
                    node.parent.color = "RED"
                    self._rotate_right(node.parent)
                    sibling = node.parent.left
                # Mirror Case 2: sibling is BLACK, and both sibling's children are BLACK
                if sibling.right.color == "BLACK" and sibling.left.color == "BLACK":
                    sibling.color = "RED"
                    node = node.parent
                else:
                    # Mirror Case 3: sibling is BLACK, sibling's left is BLACK, right is RED
                    if sibling.left.color == "BLACK":
                        sibling.right.color = "BLACK"
                        sibling.color = "RED"
                        self._rotate_left(sibling)
                        sibling = node.parent.left
                    # Mirror Case 4: sibling is BLACK, sibling's left is RED
                    sibling.color = node.parent.color
                    node.parent.color = "BLACK"
                    sibling.left.color = "BLACK"
                    self._rotate_right(node.parent)
                    node = self.root
        node.color = "BLACK"
        
    
    def _rotate_left(self, node):
        """Performs a left rotation on the given node."""
        right_child = node.right
        node.right = right_child.left

        if right_child.left != self.NIL:
            right_child.left.parent = node

        right_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = right_child
        elif node == node.parent.left:
            node.parent.left = right_child
        else:
            node.parent.right = right_child

        right_child.left = node
        node.parent = right_child

    def _rotate_right(self, node):
        """Performs a right rotation on the given node."""
        left_child = node.left
        node.left = left_child.right

        if left_child.right != self.NIL:
            left_child.right.parent = node

        left_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = left_child
        elif node == node.parent.right:
            node.parent.right = left_child
        else:
            node.parent.left = left_child

        left_child.right = node
        node.parent = left_child



# ===== Benchmarking Function =====
def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        # --- BST ---
        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        # --- AVL ---
        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

        # --- RBT ---
        rbt = RedBlackTree()
        start = time.time()
        for i in range(n):
            rbt.insert(names[i], phones[i])
        rbt_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            rbt.search(name)
        rbt_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            rbt.delete(name)
        rbt_times['delete'].append(time.time() - start)

    # Plot results
    plt.figure(figsize=(12, 8))

    # Insertions plot
    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rbt_times['insert'], label='RBT Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    # Searches plot
    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rbt_times['search'], label='RBT Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    # Deletions plot
    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.plot(sizes, rbt_times['delete'], label='RBT Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()

# Example usage:
if __name__ == "__main__":
    sizes_to_test = [100, 200, 400, 800, 1600, 3200, 4800, 6400, 8600, 10000]
    run_benchmark_for_sizes(sizes_to_test)
