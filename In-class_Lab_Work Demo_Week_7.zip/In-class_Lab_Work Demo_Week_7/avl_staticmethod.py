class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1

    @staticmethod
    def height(node):
        if not node:
            return 0
        return node.height
    
    @staticmethod
    def get_balance(node):
        if not node:
            return 0
        return AVLNode.height(node.left) - AVLNode.height(node.right)
    
    @staticmethod
    def right_rotate(z):
        y = z.left
        T3 = y.right
        
        # Rotation
        y.right = z
        z.left = T3
        
        # Update heights
        z.height = 1 + max(AVLNode.height(z.left), AVLNode.height(z.right))
        y.height = 1 + max(AVLNode.height(y.left), AVLNode.height(y.right))
        
        return y
    
    @staticmethod
    def left_rotate(z):
        y = z.right
        T2 = y.left
        
        # Rotation
        y.left = z
        z.right = T2
        
        # Update heights
        z.height = 1 + max(AVLNode.height(z.left), AVLNode.height(z.right))
        y.height = 1 + max(AVLNode.height(y.left), AVLNode.height(y.right))
        
        return y
    
    @staticmethod
    def insert_avl(node, key):
        # 1. BST insert
        if not node:
            return AVLNode(key)
        
        if key < node.key:
            node.left = AVLNode.insert_avl(node.left, key)
        else:
            node.right = AVLNode.insert_avl(node.right, key)
        
        # 2. Update height
        node.height = 1 + max(AVLNode.height(node.left), AVLNode.height(node.right))
        
        # 3. Balance
        balance = AVLNode.get_balance(node)
        
        # 4. Rotations
        
        # Left Left
        if balance > 1 and key < node.left.key:
            return AVLNode.right_rotate(node)
        
        # Right Right
        if balance < -1 and key > node.right.key:
            return AVLNode.left_rotate(node)
        
        # Left Right
        if balance > 1 and key > node.left.key:
            node.left = AVLNode.left_rotate(node.left)
            return AVLNode.right_rotate(node)
        
        # Right Left
        if balance < -1 and key < node.right.key:
            node.right = AVLNode.right_rotate(node.right)
            return AVLNode.left_rotate(node)
        
        return node
# Example: create root node
root = AVLNode(10)
root.left = AVLNode(5)
root.right = AVLNode(15)

print(f"Type of root is {type(root)}")
print(f"The key of root is {root.key}")
print(f" The left child (key) of root {root.left.key}")
print(f" The right child (key) of root {root.right.key}")

print(f"The height of root is {AVLNode.height(root)}")
