# Re-defining the Red-Black Tree class after execution reset

class RedBlackNode:
    """Represents a node in a Red-Black Tree."""
    def __init__(self, name, phone=None, color="RED"):
        self.name = name
        self.phone = phone
        self.color = color  # RED or BLACK
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    """Implements a Red-Black Tree with balancing after insertions and deletions."""
    
    def __init__(self):
        self.NIL = RedBlackNode(None, None, "BLACK")  # Sentinel NIL node
        self.root = self.NIL  # Root of the tree

    def insert(self, name, phone):
        """Inserts a new key into the Red-Black Tree and balances it."""
        new_node = RedBlackNode(name, phone)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.name < current.name:
                current = current.left
            else:
                current = current.right

        new_node.parent = parent

        if parent is None:  # Tree was empty
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "RED"  # New nodes are always inserted as RED
        self._fix_insert(new_node)  # Balance the tree

    def _fix_insert(self, node):
        """Fixes the Red-Black Tree after an insertion to maintain balance."""
        while node.parent and node.parent.color == "RED":
            grandparent = node.parent.parent

            if node.parent == grandparent.left:  # Parent is a left child
                uncle = grandparent.right

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.right:  # Case 2: Left-Right → Rotate Left
                        node = node.parent
                        self._rotate_left(node)

                    # Case 3: Left-Left → Rotate Right
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_right(grandparent)

            else:  # Parent is a right child (Mirror cases)
                uncle = grandparent.left

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.left:  # Case 2: Right-Left → Rotate Right
                        node = node.parent
                        self._rotate_right(node)

                    # Case 3: Right-Right → Rotate Left
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_left(grandparent)

        self.root.color = "BLACK"  # Ensure root is always BLACK

    def search(self, name):
        """Searches for a key in the Red-Black Tree."""
        current = self.root
        while current != self.NIL:
            if name == current.name:
                return current  # Node found
            elif name < current.name:
                current = current.left
            else:
                current = current.right
        return None  # Not found

    def delete(self, name):
        current = self.root
        while current != self.NIL:
            if name > current.name:
                current = current.right
            elif name < current.name:
                current = current.left
            else: # Node found
                check_color = current.color
                if current.left == self.NIL: # No left child
                    node_new = current.right
                    self._transplant(current, current.right)
                elif current.right == self.NIL: # No right child
                    node_new = current.left
                    self._transplant(current, current.left)
                else: # Have both children
                    temp = self._find_min(current.right)
                    check_color = temp.color
                    node_new = temp.right
                    if temp.parent == current:
                        node_new.parent = temp
                    else:
                        self._transplant(temp, temp.right)
                        temp.right = current.right
                        temp.right.parent = temp
                    self._transplant(current, temp)
                    temp.left = current.left
                    temp.left.parent = temp
                    temp.color = current.color
                if check_color == "BLACK":
                    self._fix_delete(node_new)
                return current
        return None

    def _find_min(self, root):
        current = root
        while current.left != self.NIL:
            current = current.left
        return current
        
    def _transplant(self, node, node_new):
        # Replace the Node (node) with New Node (node_new)
        if node.parent is None:
            self.root = node_new
        elif node == node.parent.left:
            node.parent.left = node_new
        else:
            node.parent.right = node_new
        node_new.parent = node.parent

    def _fix_delete(self, node):
        while node != self.root and node.color == "BLACK":
            if node == node.parent.left:
                sibling = node.parent.right
                # Case 1: sibling is RED
                if sibling.color == "RED":
                    sibling.color = "BLACK"
                    node.parent.color = "RED"
                    self._rotate_left(node.parent)
                    sibling = node.parent.right
                # Case 2: sibling is BLACK, and both sibling's children are BLACK
                if sibling.left.color == "BLACK" and sibling.right.color == "BLACK":
                    sibling.color = "RED"
                    node = node.parent
                else:
                    # Case 3: sibling is BLACK, sibling's right is BLACK, left is RED
                    if sibling.right.color == "BLACK":
                        sibling.left.color = "BLACK"
                        sibling.color = "RED"
                        self._rotate_right(sibling)
                        sibling = node.parent.right

                    # Case 4: sibling is BLACK, sibling's right is RED
                    sibling.color = node.parent.color
                    node.parent.color = "BLACK"
                    sibling.right.color = "BLACK"
                    self._rotate_left(node.parent)
                    node = self.root
            else:
                sibling = node.parent.left
                # Mirror Case 1: sibling is RED
                if sibling.color == "RED":
                    sibling.color = "BLACK"
                    node.parent.color = "RED"
                    self._rotate_right(node.parent)
                    sibling = node.parent.left
                # Mirror Case 2: sibling is BLACK, and both sibling's children are BLACK
                if sibling.right.color == "BLACK" and sibling.left.color == "BLACK":
                    sibling.color = "RED"
                    node = node.parent
                else:
                    # Mirror Case 3: sibling is BLACK, sibling's left is BLACK, right is RED
                    if sibling.left.color == "BLACK":
                        sibling.right.color = "BLACK"
                        sibling.color = "RED"
                        self._rotate_left(sibling)
                        sibling = node.parent.left
                    # Mirror Case 4: sibling is BLACK, sibling's left is RED
                    sibling.color = node.parent.color
                    node.parent.color = "BLACK"
                    sibling.left.color = "BLACK"
                    self._rotate_right(node.parent)
                    node = self.root
        node.color = "BLACK"

    def _rotate_left(self, node):
        """Performs a left rotation on the given node."""
        right_child = node.right
        node.right = right_child.left

        if right_child.left != self.NIL:
            right_child.left.parent = node

        right_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = right_child
        elif node == node.parent.left:
            node.parent.left = right_child
        else:
            node.parent.right = right_child

        right_child.left = node
        node.parent = right_child

    def _rotate_right(self, node):
        """Performs a right rotation on the given node."""
        left_child = node.left
        node.left = left_child.right

        if left_child.right != self.NIL:
            left_child.right.parent = node

        left_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = left_child
        elif node == node.parent.right:
            node.parent.right = left_child
        else:
            node.parent.left = left_child

        left_child.right = node
        node.parent = left_child

    def inorder_traversal(self, node):
        """Performs an inorder traversal of the tree."""
        if node != self.NIL:
            self.inorder_traversal(node.left)
            print(f"Contact:{node.name} Phone:{node.phone} ({node.color})\n", end="")
            self.inorder_traversal(node.right)

    def print_tree(self):
        """Prints the tree structure in a readable format."""
        def print_helper(node, indent, last):
            if node != self.NIL:
                print(indent, "`- " if last else "|- ", f"{node.name} ({node.color})", sep="")
                indent += "   " if last else "|  "
                print_helper(node.left, indent, False)
                print_helper(node.right, indent, True)

        print_helper(self.root, "", True)

# ---------------------------- TEST CASE ----------------------------

# Create a Red-Black Tree instance
rbt = RedBlackTree()

# Insert values into Red-Black Tree
names_to_insert = ['ab', 'bb', 'ca', 'aa', 'cd', 'dd', 'zs', 'de']
phones_to_insert = [1234567890, 2345678901, 3456789012, 4567890123, 5678901234, 6789012345, 7890123456, 8901234567]
for name, phone in zip(names_to_insert, phones_to_insert):
    rbt.insert(name, phone)

# Perform an inorder traversal to check tree balance
print("\nInorder Traversal After Insertions:")
rbt.inorder_traversal(rbt.root)

# Print the tree structure after insertions
print("\n\nRed-Black Tree Structure After Insertions:")
rbt.print_tree()

# Search for an existing and non-existing value
search_names = ['bb', 'cc']  # bb is present, cc is not
for name in search_names:
    found = rbt.search(name)
    print(f"\nSearching for {name}: {'Found' if found else 'Not Found'}")

# Delete an existing and non-existing value
search_names = ['cd', 'cc']  # cd is present, cc is not
for name in search_names:
    deleted = rbt.delete(name)
    print(f"\nRBT after Delete {name} ({'Deleted' if deleted else 'Not Found'}):")
    rbt.print_tree()
