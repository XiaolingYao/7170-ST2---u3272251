import tkinter as tk
from tkinter import messagebox
import time

# === Red Black Tree Node ===

class RedBlackNode:
    """Represents a node in a Red-Black Tree."""
    def __init__(self, name, phone=None, color="RED"):
        self.name = name
        self.phone = phone
        self.color = color  # RED or BLACK
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    """Implements a Red-Black Tree with balancing after insertions and deletions."""
    
    def __init__(self):
        self.NIL = RedBlackNode(None, None, "BLACK")  # Sentinel NIL node
        self.root = self.NIL  # Root of the tree

    def insert(self, name, phone):
        """Inserts a new key into the Red-Black Tree and balances it."""
        new_node = RedBlackNode(name, phone)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.name < current.name:
                current = current.left
            else:
                current = current.right

        new_node.parent = parent

        if parent is None:  # Tree was empty
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "RED"  # New nodes are always inserted as RED
        self._fix_insert(new_node)  # Balance the tree

    def _fix_insert(self, node):
        """Fixes the Red-Black Tree after an insertion to maintain balance."""
        while node.parent and node.parent.color == "RED":
            grandparent = node.parent.parent

            if node.parent == grandparent.left:  # Parent is a left child
                uncle = grandparent.right

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.right:  # Case 2: Left-Right → Rotate Left
                        node = node.parent
                        self._rotate_left(node)

                    # Case 3: Left-Left → Rotate Right
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_right(grandparent)

            else:  # Parent is a right child (Mirror cases)
                uncle = grandparent.left

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.left:  # Case 2: Right-Left → Rotate Right
                        node = node.parent
                        self._rotate_right(node)

                    # Case 3: Right-Right → Rotate Left
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_left(grandparent)

        self.root.color = "BLACK"  # Ensure root is always BLACK

    def search(self, name):
        """Searches for a key in the Red-Black Tree."""
        current = self.root
        while current != self.NIL:
            if name == current.name:
                return current  # Node found
            elif name < current.name:
                current = current.left
            else:
                current = current.right
        return None  # Not found

    def delete(self, name):
        current = self.root
        while current != self.NIL:
            if name > current.name:
                current = current.right
            elif name < current.name:
                current = current.left
            else: # Node found
                check_color = current.color
                if current.left == self.NIL: # No left child
                    node_new = current.right
                    self._transplant(current, current.right)
                elif current.right == self.NIL: # No right child
                    node_new = current.left
                    self._transplant(current, current.left)
                else: # Have both children
                    temp = self._find_min(current.right)
                    check_color = temp.color
                    node_new = temp.right
                    if temp.parent == current:
                        node_new.parent = temp
                    else:
                        self._transplant(temp, temp.right)
                        temp.right = current.right
                        temp.right.parent = temp
                    self._transplant(current, temp)
                    temp.left = current.left
                    temp.left.parent = temp
                    temp.color = current.color
                if check_color == "BLACK":
                    self._fix_delete(node_new)
                return current
        return None

    def _find_min(self, root):
        current = root
        while current.left != self.NIL:
            current = current.left
        return current
        
    def _transplant(self, node, node_new):
        # Replace the Node (node) with New Node (node_new)
        if node.parent is None:
            self.root = node_new
        elif node == node.parent.left:
            node.parent.left = node_new
        else:
            node.parent.right = node_new
        node_new.parent = node.parent

    def _fix_delete(self, node):
        while node != self.root and node.color == "BLACK":
            if node == node.parent.left:
                sibling = node.parent.right
                # Case 1: sibling is RED
                if sibling.color == "RED":
                    sibling.color = "BLACK"
                    node.parent.color = "RED"
                    self._rotate_left(node.parent)
                    sibling = node.parent.right
                # Case 2: sibling is BLACK, and both sibling's children are BLACK
                if sibling.left.color == "BLACK" and sibling.right.color == "BLACK":
                    sibling.color = "RED"
                    node = node.parent
                else:
                    # Case 3: sibling is BLACK, sibling's right is BLACK, left is RED
                    if sibling.right.color == "BLACK":
                        sibling.left.color = "BLACK"
                        sibling.color = "RED"
                        self._rotate_right(sibling)
                        sibling = node.parent.right

                    # Case 4: sibling is BLACK, sibling's right is RED
                    sibling.color = node.parent.color
                    node.parent.color = "BLACK"
                    sibling.right.color = "BLACK"
                    self._rotate_left(node.parent)
                    node = self.root
            else:
                sibling = node.parent.left
                # Mirror Case 1: sibling is RED
                if sibling.color == "RED":
                    sibling.color = "BLACK"
                    node.parent.color = "RED"
                    self._rotate_right(node.parent)
                    sibling = node.parent.left
                # Mirror Case 2: sibling is BLACK, and both sibling's children are BLACK
                if sibling.right.color == "BLACK" and sibling.left.color == "BLACK":
                    sibling.color = "RED"
                    node = node.parent
                else:
                    # Mirror Case 3: sibling is BLACK, sibling's left is BLACK, right is RED
                    if sibling.left.color == "BLACK":
                        sibling.right.color = "BLACK"
                        sibling.color = "RED"
                        self._rotate_left(sibling)
                        sibling = node.parent.left
                    # Mirror Case 4: sibling is BLACK, sibling's left is RED
                    sibling.color = node.parent.color
                    node.parent.color = "BLACK"
                    sibling.left.color = "BLACK"
                    self._rotate_right(node.parent)
                    node = self.root
        node.color = "BLACK"
        
    
    def _rotate_left(self, node):
        """Performs a left rotation on the given node."""
        right_child = node.right
        node.right = right_child.left

        if right_child.left != self.NIL:
            right_child.left.parent = node

        right_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = right_child
        elif node == node.parent.left:
            node.parent.left = right_child
        else:
            node.parent.right = right_child

        right_child.left = node
        node.parent = right_child

    def _rotate_right(self, node):
        """Performs a right rotation on the given node."""
        left_child = node.left
        node.left = left_child.right

        if left_child.right != self.NIL:
            left_child.right.parent = node

        left_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = left_child
        elif node == node.parent.right:
            node.parent.right = left_child
        else:
            node.parent.left = left_child

        left_child.right = node
        node.parent = left_child

    def inorder_traversal(self, node, res=None):
        if res is None:
            res = []
        if node != self.NIL:
            self.inorder_traversal(node.left, res)
            res.append((node.name, node.phone))
            self.inorder_traversal(node.right, res)
        return res

# === Tkinter GUI App ===

class RBTApp:
    def __init__(self, master):
        self.tree = RedBlackTree()

        self.master = master
        master.title("Red Black Tree Contact Directory")

        # Input frame
        self.frame = tk.Frame(master)
        self.frame.pack(pady=10)

        tk.Label(self.frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(self.frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(self.frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(self.frame)
        self.phone_entry.grid(row=1, column=1)

        # Buttons
        self.btn_frame = tk.Frame(master)
        self.btn_frame.pack(pady=5)

        tk.Button(self.btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(self.btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(self.btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(self.btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)

        # Output text box
        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        # Canvas for tree visualization
        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return
        self.tree.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to search.")
            return
        node = self.tree.search(name)
        self.output_text.delete(1.0, tk.END)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter Name to delete.")
            return
        self.tree.delete(name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder_traversal(self.tree.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for n, p in contacts:
                self.output_text.insert(tk.END, f"Name: {n}, Phone: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return

        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()
        self._draw_node(self.tree.root, width // 2, 20, width // 4)

    def _draw_node(self, node, x, y, x_offset):
        if node == self.tree.NIL:
            return

        radius = 20
        # Draw left subtree + edge
        if node.left:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y+radius, x_left, y_left - radius)
            self._draw_node(node.left, x_left, y_left, x_offset // 2)

        # Draw right subtree + edge
        if node.right:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y+radius, x_right, y_right - radius)
            self._draw_node(node.right, x_right, y_right, x_offset // 2)

        # Draw node circle & color
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=node.color.lower())

        # Draw text - shortened name if long
        display_name = node.name if len(node.name) <= 10 else node.name[:10] + "..."
        self.canvas.create_text(x, y, text=display_name, font=("Arial", 10, "bold"), fill="white")
        
        
        
# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = RBTApp(root)
    root.mainloop()
