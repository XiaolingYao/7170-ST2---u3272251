from collections import deque


class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

    @staticmethod
    def preorder(root):
        if root:
            print(root.value, end=' ')
            Node.preorder(root.left)
            Node.preorder(root.right)

    @staticmethod
    def inorder(root):
        if root:
            Node.inorder(root.left)
            print(root.value, end=' ')
            Node.inorder(root.right)

    @staticmethod
    def postorder(root):
        if root:
            Node.postorder(root.left)
            Node.postorder(root.right)
            print(root.value, end=' ')

    @staticmethod
    def count_nodes(root):
        if root is None:
            return 0
        return 1 + Node.count_nodes(root.left) + Node.count_nodes(root.right)

    @staticmethod
    def height(root):
        if root is None:
            return 0
        return 1 + max(Node.height(root.left), Node.height(root.right))

    @staticmethod
    def search_bst(root, val):
        if root is None or root.value == val:
            return root
        if val < root.value:
            return Node.search_bst(root.left, val)
        else:
            return Node.search_bst(root.right, val)

    @staticmethod
    def insert_bst(root, val):
        if root is None:
            return Node(val)
        if val < root.value:
            root.left = Node.insert_bst(root.left, val)
        else:
            root.right = Node.insert_bst(root.right, val)
        return root

    @staticmethod
    def find_min(root):
        current = root
        while current.left:
            current = current.left
        return current

    @staticmethod
    def delete_node(root, val):
        if root is None:
            return root
        if val < root.value:
            root.left = Node.delete_node(root.left, val)
        elif val > root.value:
            root.right = Node.delete_node(root.right, val)
        else:
            # Node with 1 or no child
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            # Node with two children
            temp = Node.find_min(root.right)
            root.value = temp.value
            root.right = Node.delete_node(root.right, temp.value)
        return root

    @staticmethod
    def level_order(root):
        if not root:
            return
        queue = deque([root])
        while queue:
            node = queue.popleft()
            print(node.value, end=' ')
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)


# Example: create root node
root = Node(10)
root.left = Node(5)
root.right = Node(15)

print(type(root))
print(root.value)
print(f"The left child (value) of root {root.left.value}")
print(f"The right child (value) of root {root.right.value}")

print(f"There are {Node.count_nodes(root)} nodes in root")
