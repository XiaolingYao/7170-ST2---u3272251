from collections import deque


class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

# Example: create root node
root = Node(10)
root.left = Node(5)
root.right = Node(15)

def preorder(root):
    if root:
        print(root.value, end=' ')
        preorder(root.left)
        preorder(root.right)

def inorder(root):
    if root:
        inorder(root.left)
        print(root.value, end=' ')
        inorder(root.right)

def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.value, end=' ')

def count_nodes(root):
    if root is None:
        return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)


def height(root):
    if root is None:
        return 0
    return 1 + max(height(root.left), height(root.right))

def search_bst(root, val):
    if root is None or root.value == val:
        return root
    if val < root.value:
        return search_bst(root.left, val)
    else:
        return search_bst(root.right, val)

def insert_bst(root, val):
    if root is None:
        return Node(val)
    if val < root.value:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def find_min(root):
    current = root
    while current.left:
        current = current.left
    return current

def delete_node(root, val):
    if root is None:
        return root
    if val < root.value:
        root.left = delete_node(root.left, val)
    elif val > root.value:
        root.right = delete_node(root.right, val)
    else:
        # Node with 1 or no child
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        # Node with two children
        temp = find_min(root.right)
        root.value = temp.value
        root.right = delete_node(root.right, temp.value)
    return root

def level_order(root):
    if not root:
        return
    queue = deque([root])
    while queue:
        node = queue.popleft()
        print(node.value, end=' ')
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)

print(f"Type of root is {type(root)}")
print(f"The value of root is {root.value}")
print(f" The left child (value) of root {root.left.value}")
print(f" The right child (value) of root {root.right.value}")

print("\npreorder")
preorder(root)
print("\ninorder")
inorder(root)
print("\npostorder")
postorder(root)
print("\nlevel_order")
level_order(root)

print()
print(f"There are {count_nodes(root)} nodes in root")
print(f"The height of root is {height(root)}")

print()
print("Preorder after insert a value 6 and 7:")
insert_bst(root, 6)
insert_bst(root, 7)
preorder(root)

print()
print("Preorder after delete a value 6:")
delete_node(root, 6)
preorder(root)

print()
print(f"Search value 5: {search_bst(root, 5).value} is found in {search_bst(root, 5)}")
