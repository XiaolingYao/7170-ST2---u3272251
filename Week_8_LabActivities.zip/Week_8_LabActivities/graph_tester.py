from graph import Graph 


# TASK 1
print("Task 1")
#Basic undirected graph tests
print("Basic undirected graph tests:")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()

# Directed graph tests
print("Directed graph tests:")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()


# Weighted graph tests
print("Weighted graph tests:")
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)

g.print_graph()

# Removal tests
print()
print("Removal test")
removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')

print("The initial graph:")
removal_test.print_graph()

print("Remove edge AB:")
removal_test.remove_edge('A', 'B')
removal_test.print_graph()

print("Remove vertex C:")
removal_test.remove_vertex('C')

removal_test.print_graph()
print()


# TASK 2
print("Task 2")
#Basic undirected graph tests
print("Test with the basic undirected graph in task 1:")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()

# BFS on the graph from Activity 1
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

print()

print("Test with the directed graph A → B → C and additional connections:")
# Directed graph tests
print("Directed graph tests:")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')
g.add_vertex('F')
g.add_vertex('G')
g.add_vertex('H')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('B', 'E')
g.add_edge('D', 'F')
g.add_edge('D', 'G')
g.add_edge('C', 'H')

g.print_graph()

# BFS on the graph
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

print()

# TASK 3
print("Task 3")
#Basic undirected graph tests
print("Test with the basic undirected graph in task 1:")
g.print_graph()
# DFS on the same graph
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()

# Compare BFS and DFS (without cycles)
print("Test and compare with BFS for the same graph (without cycles):")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')
g.add_vertex('F')
g.add_vertex('G')


g.add_edge('A', 'B')
g.add_edge('B', 'D')
g.add_edge('B', 'E')
g.add_edge('A', 'C')
g.add_edge('D', 'F')
g.add_edge('D', 'G')

g.print_graph()

# BFS on the same graph
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
# DFS on the same graph
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()

# Compare BFS and DFS (with cycles)
print("Test and compare with BFS for the same graph (with cycles):")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')
g.add_vertex('F')
g.add_vertex('G')


g.add_edge('A', 'B')
g.add_edge('B', 'D')
g.add_edge('B', 'E')
g.add_edge('A', 'C')
g.add_edge('D', 'F')
g.add_edge('D', 'G')
g.add_edge('B', 'C') # cycle added
g.add_edge('D', 'E') # cycle added

g.print_graph()

# BFS on the same graph
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
# DFS on the same graph
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()


# TASK 4
print("Task 4")
#cycle detection in undirected graphs
# Create graph with a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # Closing the cycle

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())
print()


# TASK 5
print("Task 5")
# Create weighted directed graph
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()
print(f"The shortest path from A to C is: {wg.shortest_path_weight('A','C')}")

