class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 not in self.graph or vertex2 not in self.graph:
            print("At least one vertex not detected, please check your input.")
            return
        # delete vertex1 -> vertex2
        if vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted:
                self.weights.pop((vertex1, vertex2), None)
        # In the case of an undirected graph, delete vertex2 -> vertex1
        if not self.directed:
            if vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if self.weighted:
                    self.weights.pop((vertex2, vertex1), None)
            
    def remove_vertex(self, vertex):
        if vertex not in self.graph:
            print(f"The vertex {vertex} does not exist")
            return
        # remove related weights
        for edge in list(self.weights.keys()):
            if vertex in edge:
                self.weights.pop(edge, None)
        # remove vertex from adjacency lists
        for eachvertex in self.graph:
            if vertex in self.graph[eachvertex]:
                self.graph[eachvertex].remove(vertex)
        # remove the vertex itself
        self.graph.pop(vertex, None)
    
    def print_graph(self):
        if not self.graph:
            print("Graph is empty.")
            
        for vertex in self.graph:
            print(f"{vertex} -> ", end="")
            for neighbor in self.graph[vertex]:
                if self.weighted:
                    weight = self.weights.get((vertex, neighbor), 0)
                    print(f"{neighbor}({weight})", end=" ")
                else:
                    print(f"{neighbor}", end=" ")
            print()

    def bfs(self, start):
        if start not in self.graph:
            print(f"The vertex {start} does not exist")
        visited = set()
        visited_bfs = []
        queue = [start]
        while queue:
            visit = queue.pop(0)
            if visit not in visited:
                visited_bfs.append(visit)
                visited.add(visit)
                for neighbor in self.graph[visit]:
                    if neighbor not in visited:
                        queue.append(neighbor)
        return visited_bfs

    def dfs(self, start):
        if start not in self.graph:
            print(f"The vertex {start} does not exist")
        visited = set()
        visited_dfs = []
        stack = [start]
        while stack:
            visit = stack.pop()
            if visit not in visited:
                visited_dfs.append(visit)
                visited.add(visit)
                for neighbor in reversed(self.graph[visit]):
                    if neighbor not in visited:
                        stack.append(neighbor)
        return visited_dfs
                
    def has_undirected_cycle(self):
        if not self.graph:
            print("Graph is empty.")
            return
        visited = set()
        for vertex in self.graph:
            if vertex not in visited:
                if self._dfs_cycle(vertex, visited, parent=None):
                    return True
        return False
            
    def _dfs_cycle(self, visit, visited, parent):
        visited.add(visit)
        for neighbor in self.graph[visit]:
            if neighbor not in visited:
                if self._dfs_cycle(neighbor, visited, visit):
                    return True
            elif neighbor != parent: #cycle found
                return True 
        return False

    def shortest_path_weight(self, start, target):
        if start not in self.graph or target not in self.graph:
            print("At least one vertex not detected, please check your input.")
            return None
        distances = {vertex: float('inf') for vertex in self.graph}
        previous = {vertex:None for vertex in self.graph}
        distances[start] = 0
        visited = set()
        while True:
            current = None
            current_dist = float('inf')
            for vertex in self.graph:
                if vertex not in visited and distances[vertex] < current_dist:
                    current = vertex
                    current_dist = distances[vertex]
            if current is None:
                break
            if current == target:
                break
            visited.add(current)
            for neighbor in self.graph[current]:
                weight = self.weights.get((current, neighbor), 0)
                new_dist = distances[current] + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    previous[neighbor] = current
        if distances[target] == float('inf'):
            return None
        # reconstruct path
        path = []
        cur = target
        while cur is not None:
            path.append(cur)
            cur = previous[cur]

        path.reverse()
        return distances[target], path
        



        
