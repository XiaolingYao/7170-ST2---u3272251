#extended_graph_visualiser_from_task6.py

from graph import Graph
import tkinter as tk
from tkinter import messagebox
import math
import time

class GraphVisualizer(tk.Tk):
    def __init__(self):
        super().__init__()

        self.graph = Graph(directed=True, weighted=True)

        self.title("Graph Visualizer")
        # Top frame for Inputs
        frame = tk.Frame(self)
        frame.pack(pady=10)

        tk.Label(frame, text="Vertex:").grid(row=0, column=0, padx=5)
        self.vertex_entry = tk.Entry(frame)
        self.vertex_entry.grid(row=0, column=1, columnspan=5, padx=5, sticky="ew")
        self.add_vertex_btn = tk.Button(frame, text="Add", command=self.add_vertex)
        self.add_vertex_btn.grid(row=0, column=6, padx=5)
        self.remove_vertex_btn = tk.Button(frame, text="Remove", command=self.remove_vertex)
        self.remove_vertex_btn.grid(row=0, column=7, padx=5)

        tk.Label(frame, text="Edge from:").grid(row=1, column=0, padx=5)
        tk.Label(frame, text="To:").grid(row=1, column=2, padx=5)
        tk.Label(frame, text="Weight(optional):").grid(row=1, column=4, padx=5)
        self.vertex1_entry = tk.Entry(frame)
        self.vertex2_entry = tk.Entry(frame)
        self.weight_entry = tk.Entry(frame)
        self.vertex1_entry.grid(row=1, column=1, padx=5)
        self.vertex2_entry.grid(row=1, column=3, padx=5)
        self.weight_entry.grid(row=1, column=5, padx=5)
        self.add_edge_btn = tk.Button(frame, text="Add", command=self.add_edge)
        self.add_edge_btn.grid(row=1, column=6, padx=5)
        self.remove_edge_btn = tk.Button(frame, text="Remove", command=self.remove_edge)
        self.remove_edge_btn.grid(row=1, column=7, padx=5)
        

        tk.Label(frame, text="BFS from:").grid(row=2, column=0, padx=5)
        self.vertex_bfs_entry = tk.Entry(frame)
        self.vertex_bfs_entry.grid(row=2, column=1, columnspan=5, padx=5, sticky="ew")
        self.bfs_btn = tk.Button(frame, text="Show", command=self.bfs)
        self.bfs_btn.grid(row=2, column=7, padx=5)

        tk.Label(frame, text="DFS from:").grid(row=3, column=0, padx=5)
        self.vertex_dfs_entry = tk.Entry(frame)
        self.vertex_dfs_entry.grid(row=3, column=1, columnspan=5, padx=5, sticky="ew")
        self.dfs_btn = tk.Button(frame, text="Show", command=self.dfs)
        self.dfs_btn.grid(row=3, column=7, padx=5)

        tk.Label(frame, text="Directed Graph?").grid(row=4, column=3, padx=5)
        self.directed_var = tk.BooleanVar(value=self.graph.directed)
        chk = tk.Checkbutton(frame, text="Enable", variable=self.directed_var, command=self.directed_switch)
        chk.grid(row=4, column=4, padx=5)

        #Detect cycles
        self.btn_cycle_undirected = tk.Button(frame, text="Detect Undirected Cycle", command=self.run_cycle_detection)
        self.btn_cycle_undirected.grid(row=5, column=1, padx=5)
        self.btn_cycle_directed = tk.Button(frame, text="Detect Directed Cycle", command=self.run_directed_cycle_detection)
        self.btn_cycle_directed.grid(row=5, column=3, padx=5)
        self.btn_reset = tk.Button(frame, text="Reset Colors", command=self.reset_colors)
        self.btn_reset.grid(row=5, column=5, padx=5)
        
        for i in range(1, 6):
            frame.grid_columnconfigure(i, weight=1)
        
        # Canvas to visualize
        self.canvas = tk.Canvas(self, width=800, height=400, bg='white')
        self.canvas.pack()


        self.vertex_positions = {}
        self.vertex_items = {}
        self.draw_graph()
        

    def draw_graph(self):
        self.canvas.delete("all")
        radius = 20
        spacing = 100
        
        # Arrange vertices in a circle
        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 400, 200
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            oval_id = self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill='lightblue')
            self.vertex_items[v] = oval_id
            self.canvas.create_text(x, y, text=v)

        # Draw edges
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST if self.graph.directed else None)
                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

    def add_vertex(self):
        vertex = self.vertex_entry.get().strip()
        if vertex == "":
            messagebox.showwarning("Input Error", "Please enter a vertex")
            return
        self.graph.add_vertex(vertex)
        self.draw_graph()
        
    def add_edge(self):
        vertex1 = self.vertex1_entry.get().strip()
        vertex2 = self.vertex2_entry.get().strip()
        weight = self.weight_entry.get()
        if vertex1 == "" or vertex2 =="":
            messagebox.showwarning("Input Error", "Please enter both vertexes")
            return
        if weight == "":
            weight = 0
        else:
            try:
                weight = float(weight)
            except ValueError:
                messagebox.showerror("Input Error", "Weight must be a number or leave empty")
                return
        self.graph.add_edge(vertex1, vertex2, weight)
        self.draw_graph()
        
    def remove_vertex(self):
        vertex = self.vertex_entry.get().strip()
        if vertex == "":
            messagebox.showwarning("Input Error", "Please enter a vertex")
            return
        self.graph.remove_vertex(vertex)
        self.draw_graph()
        
    def remove_edge(self):
        vertex1 = self.vertex1_entry.get().strip()
        vertex2 = self.vertex2_entry.get().strip()
        if vertex1 == "" or vertex2 =="":
            messagebox.showwarning("Input Error", "Please enter both vertexes")
            return
        self.graph.remove_edge(vertex1, vertex2)
        self.draw_graph()
        
    def bfs(self):
        vertex = self.vertex_bfs_entry.get().strip()
        if vertex == "":
            messagebox.showwarning("Input Error", "Please enter a start vertex")
            return
        bfs_order = self.graph.bfs(vertex)
        for v in bfs_order:
            self.canvas.itemconfig(self.vertex_items[v], fill='lightblue')
        self.highlight(bfs_order, 0)
        
    def dfs(self):
        vertex = self.vertex_dfs_entry.get().strip()
        if vertex == "":
            messagebox.showwarning("Input Error", "Please enter a start vertex")
            return
        dfs_order = self.graph.dfs(vertex)
        for v in dfs_order:
            self.canvas.itemconfig(self.vertex_items[v], fill='lightblue')
        self.highlight(dfs_order, 0)

    def highlight(self, order_list, index):
        if index >= len(order_list):
            return
        v = order_list[index]
        self.canvas.itemconfig(self.vertex_items[v], fill='yellow')
        self.after(500, lambda: self.highlight(order_list, index + 1))

    def directed_switch(self):
        new_directed = self.directed_var.get()
        confirm = messagebox.askyesno(
            "Reset Graph",
            "Switching graph type will clear the current graph. Continue?"
        )

        if not confirm:
            self.directed_var.set(self.graph.directed)
            return
        self.graph = Graph(directed=new_directed, weighted=True)
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_items.clear()
        
    def reset_colors(self):
        for v in self.vertex_items:
            self.canvas.itemconfig(self.vertex_items[v], fill='lightblue')

    def run_cycle_detection(self):
        self.reset_colors()

        if self.graph.directed:
            messagebox.showwarning("Error", "Undirected cycle detection works only on undirected graphs.")
            return

        visited = set()
        has_cycle = False

        def cycle_dfs(current, visited_set, parent):
            visited_set.add(current)
            self.highlight_vertex(current, 'yellow')
            self.update()
            time.sleep(0.5)

            for nbr in self.graph.graph[current]:
                if nbr not in visited_set:
                    if cycle_dfs(nbr, visited_set, current):
                        self.highlight_vertex(current, 'red')
                        self.update()
                        time.sleep(0.3)
                        return True
                elif parent != nbr:
                    self.highlight_vertex(nbr, 'red')
                    self.highlight_vertex(current, 'red')
                    self.update()
                    time.sleep(0.5)
                    return True
            return False

        for vertex in self.graph.graph:
            if vertex not in visited:
                if cycle_dfs(vertex, visited, None):
                    has_cycle = True
                    break

        if not has_cycle:
            messagebox.showwarning("Error", "No cycles found in the undirected graph.")

    def run_directed_cycle_detection(self):
        self.reset_colors()
        if not self.graph.directed:
            messagebox.showwarning("Error", "Directed cycle detection works only on directed graphs.")
            return

        visited = set()
        rec_stack = set()
        has_cycle = False

        def dfs(vertex):
            visited.add(vertex)
            rec_stack.add(vertex)
            self.highlight_vertex(vertex, 'yellow')
            self.update()
            time.sleep(0.5)

            for nbr in self.graph.graph[vertex]:
                if nbr not in visited:
                    if dfs(nbr):
                        self.highlight_vertex(nbr, 'red')
                        self.highlight_vertex(vertex, 'red')
                        self.update()
                        time.sleep(0.5)
                        return True
                elif nbr in rec_stack:
                    self.highlight_vertex(nbr, 'red')
                    self.highlight_vertex(vertex, 'red')
                    self.update()
                    time.sleep(0.5)
                    return True

            rec_stack.remove(vertex)
            return False

        for vertex in self.graph.graph:
            if vertex not in visited:
                if dfs(vertex):
                    has_cycle = True
                    break

        if not has_cycle:
            messagebox.showwarning("Error", "No cycles found in the directed graph.")

    def highlight_vertex(self, vertex, color):
        circle_id = self.vertex_items.get(vertex)
        if circle_id:
            self.canvas.itemconfig(circle_id, fill=color)
            self.update()
            
if __name__ == "__main__":
    app = GraphVisualizer()
    app.mainloop()
