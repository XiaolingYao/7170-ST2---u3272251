import timeit
import random

# LINEAR SEARCH

def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1


# BINARY SEARCH

def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1


# Comparing linear and binary search efficiency
# Generate a unsorted and sorted lists of integers for testing

# Test cases (Efficiency test only, cuz binary search requires sorted list)
testScales = [10**1, 10**3, 10**5, 10**7]

for testScale in testScales:
    print("\n The data size for this test is ", testScale, ":")
    test = unsorted_list = [random.randint(0, testScale) for _ in range(testScale)]
    target = random.randint(0, testScale)  # Random target value
    
    linear_time = timeit.timeit(lambda: linear_search(test, target), number=100)
    print(f"Linear search execution time: {linear_time:.6f} seconds")
    
    sorted_list = list(range(testScale))
    linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
    binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)
    print(f"Linear search execution time for the sorted list: {linear_time:.6f} seconds")
    print(f"Binary search execution time for the sorted list: {binary_time:.6f} seconds")
