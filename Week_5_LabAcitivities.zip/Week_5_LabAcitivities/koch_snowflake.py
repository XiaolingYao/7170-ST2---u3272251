from tkinter import * # Import tkinter
import math

class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch Snowflake") # Set a title
        self.width = 200
        self.height = 250
        self.canvas = Canvas(window,
        width = self.width, height = self.height)
        self.canvas.pack()
        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()
        Label(frame1,
        text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable = self.order,
        justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display Koch Snowflake", command = self.display).pack(side = LEFT)
        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")
        p1 = [self.width / 2, 10]
        p2 = [10, self.width - 10]
        p3 = [self.width - 10, self.width - 10]
        self.displaySnowflake(int(self.order.get()), p1, p2, p3)

    def displaySnowflake(self, order, p1, p2, p3):
            self.drawKoch(order, p1, p2)
            self.drawKoch(order, p2, p3)
            self.drawKoch(order, p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0:
            # Base condition
            # Draw a Line to connect end points
            self.drawLine(p1, p2)
        else:
            # Get the one third and two third point of each triangle's edge
            p121 = self.nthirdpoint(1, p1, p2)
            p122 = self.nthirdpoint(2, p1, p2)
            #Get the out-ward equilateral triangle peak point
            p12 = self.peakpoint(p121, p122)

            #Draw a Koch Line to connect all points: end -> 1/3 -> peak -> 2/3 -> end
            self.drawKoch(order - 1, p1, p121)
            self.drawKoch(order - 1, p121, p12)
            self.drawKoch(order - 1, p12, p122)
            self.drawKoch(order - 1, p122, p2)
 
    def drawLine(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags = "line")

    # Return the nth (n=1 or n=2) third between two points
    def nthirdpoint(self, n, p1, p2):
        p = 2 * [0]
        p[0] = p1[0] + (p2[0] - p1[0]) / 3 * n
        p[1] = p1[1] + (p2[1] - p1[1]) / 3 * n
        return p

    # Return the peak point of equilateral triangle
    def peakpoint(self, pnn1, pnn2):
        p = 2 * [0]
        d = [pnn2[0] - pnn1[0], pnn2[1] - pnn1[1]]
        p[0] = pnn1[0] + 0.5 * d[0] - math.sqrt(3) / 2 * d[1]
        p[1] = pnn1[1] + math.sqrt(3) / 2 * d[0] + 0.5 * d[1]
        return p
    

KochSnowflake() # Create GUI
