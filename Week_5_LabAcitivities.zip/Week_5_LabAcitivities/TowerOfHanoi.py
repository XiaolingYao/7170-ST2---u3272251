#Initial the number of moves
moves = 0

def main():
    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print(f"The number of moves is {moves}")

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global moves
    moves += 1
    if n == 1: # Stopping condition
        #print("Move disk", n, "from", fromTower, "to", toTower)
        return
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        #print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
        
main() # Call the main function
