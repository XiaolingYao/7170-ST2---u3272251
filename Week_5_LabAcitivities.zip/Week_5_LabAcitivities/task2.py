import random
import timeit

# TASK 2

# TASK 2 (1)
print("\n\nTask 2 (1)")

# MINI-PROJECT: MERGE SORT (A real-world sorting algorithm)
# Merge sort is a sorting algorithm which is
# efficient enough to be commonly used in practice.
# The idea of merge sort is to split a list up
# into smaller and smaller pieces until all that
# remains are single element lists. Since single
# element lists are necessarily sorted, this is
# our 'base case', and we can then start to
# reassemble the list in sorted order.


def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2] # Integer division
        right_split = array[len(array)//2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)        

        return merge(left, right)

        
def merge(left, right):
    merged = []

    left_pointer = 0
    right_pointer = 0

    merging = True

    while merging:

        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element: # Equal items
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1

        if left_pointer >= len(left): # Reached end of left list
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right): # Reached end of right list
            merged.extend(left[left_pointer:])
            merging = False

    return merged


# Merge sort test cases

print("A functional test for merge sort function:")
l = [random.randint(1, 10) for _ in range(10)]
print(f"The unsorted list: {l}")
sorted = merge_sort(l)
print(f"The sorted list: {sorted}")


# Test the merge-sort algorithm for different data sizes

print("\n\nTest the merge-sort algorithm for different data sizes:")

def test_merge_sort(testScale):
    print("\nThe data size for this test is ", testScale, ":")
    unsorted_list = [random.randint(0, testScale * 2) for _ in range(testScale)]
    merge_time = timeit.timeit(lambda: merge_sort(unsorted_list[:]), number=10)
    print(f"Merge Sort took: {merge_time:.6f} seconds")

#test 
testScales = [10**1, 10**2, 10**3, 10**4, 10**5]
for test_scale in testScales:
    test_merge_sort(test_scale)



# TASK 2 (2)
print("\n\nTask 2 (2)")

# INSERTION SORT
def insertion_sort(arr):

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr


# Test the insertion sort algorithm for different data sizes (Due to the inefficiency, timeout is manually set)

print("Test the insertion sort algorithm with similar test data sequences as in (1):")

def test_insertion_sort(testScale):
    print("\nThe data size for this test is ", testScale, ":")
    if testScale >= 100000:
        print("Insertion Sort skipped because the running time would be excessive.")
        return
    unsorted_list = [random.randint(0, testScale * 2) for _ in range(testScale)]
    merge_time = timeit.timeit(lambda: insertion_sort(unsorted_list[:]), number=10)
    print(f"Insertion Sort took: {merge_time:.6f} seconds")

#test
testScales = [10**1, 10**2, 10**3, 10**4, 10**5]
for test_scale in testScales:
    test_insertion_sort(test_scale)


# TASK 2 (3)
print("\n\nTask 2 (3)")

# Benchmark the algorithm efficiency

def benchmark_efficiency_merge_insertion(testScale):
    unsorted_list = [random.randint(0, testScale * 2) for _ in range(testScale)]

    execution_time_merge = timeit.timeit(lambda: merge_sort(unsorted_list[:]), number=10)
    print(f"Merge Sort with data size {testScale} took {execution_time_merge:.6f} seconds")
    if test_scale >= 100000:
        print("Insertion Sort skipped because the running time would be excessive.")
    else:
        execution_time_insertion = timeit.timeit(lambda: insertion_sort(unsorted_list[:]), number=10)
        print(f"Insertion Sort with data size {testScale} took {execution_time_insertion:.6f} seconds")

#test
testScales = [10**1, 10**2, 10**3, 10**4, 10**5]
for test_scale in testScales:
    benchmark_efficiency_merge_insertion(test_scale)
    
