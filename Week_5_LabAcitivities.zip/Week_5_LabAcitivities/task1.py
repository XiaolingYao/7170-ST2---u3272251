import random
import timeit

#TASK 1

#TASK 1 (1)

print(f"\n(1) Test running recursion algorithms:")
# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
result = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers is {result}")


# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
result = fibonacci(7)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 7th Fibonacci number is {result}")



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result}")


###############

#TASK 1 (2)

print(f"\n(2)Convert to iteration and test run:")

#Basic Recursion Examples to Iteration

#Sum of Natural Numbers - Interation

def sum_of_natural_numbers_iteration(n):
    result = 1
    if n <= 1:
        return result # Base case
    else:
        while n > 1:
            result += n
            n -= 1
        return result

# Example usage:
result = sum_of_natural_numbers_iteration(5)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers calculated by iteration is {result}")

#Calculate fibonacci - Iteration

def fibonacci_iteration(n):
    num_one = 0
    num_two = 1
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case
    else:
        i = 1
        result = 0
        while i < n:
            result = num_one + num_two
            num_one = num_two
            num_two = result
            i += 1
        return result

# Example usage:
num = 7
result = fibonacci_iteration(num)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The {num}th Fibonacci number calculated by iteration is {result}")


#Calculate the factorial - Iteration

def factorial_iteration(n):
    """
    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1 # Base case: factorial of 0 is 1
    else:
        result = 1
        while n > 0:
            result = result * n
            n -= 1
        return result

# Example usage:
num = 5
result = factorial_iteration(num)
print(f"The factorial of {num} calculated by iteration is {result}")


###############

#TASK 1 (3)

print(f"\n(3)Compare recursion and iteration for different data sizes:")

# Test cases (Recursion vs Iteration for different data sizes)
# Start from data size around 1000, recursion algorithms will fail with RecursionError: maximum recursion depth exceeded

def test(test_case):
    print(f"\nExecution time for data size {test_case}:")
    try:
        sum_of_natural_numbers_time = timeit.timeit(lambda: sum_of_natural_numbers(test_case), number=1)
    except RecursionError:
        print(f"Maximum recursion depth exceeded when data size is greater than {test_case}: sum of natural numbers by recursion failed")
        sum_of_natural_numbers_time = 99999999
    sum_of_natural_numbers_iteration_time = timeit.timeit(lambda: sum_of_natural_numbers_iteration(test_case), number=1)

    if test_case < 50:
        fibonacci_time = timeit.timeit(lambda: fibonacci(test_case), number=1)
    else:
        print(f"When data size is greater than 50, the running is risky, fabinacci by recursion failed")
        fibonacci_time = 99999999
    fibonacci_iteration_time = timeit.timeit(lambda: fibonacci_iteration(test_case), number=1)

    try:
        factorial_time = timeit.timeit(lambda: factorial(test_case), number=1)
    except RecursionError:
        print(f"Maximum recursion depth exceeded when data size is greater than {test_case}: factorial by recursion failed")
        factorial_time = 99999999
    factorial_iteration_time = timeit.timeit(lambda: factorial_iteration(test_case), number=1)

    print(f"""
Sum of Natural Numbers by Recursion: {sum_of_natural_numbers_time:.6f} seconds
Sum of Natural Numbers by Iteration: {sum_of_natural_numbers_iteration_time:.6f} seconds
Calculate the {test_case}th Number of Fibonacci by Recursion: {fibonacci_time:.6f} seconds
Calculate the {test_case}th Number of Fibonacci by Iteration: {fibonacci_iteration_time:.6f} seconds
Calculate the Factorial of {test_case} by Recursion: {factorial_time:.6f} seconds
Calculate the Factorial of {test_case} by Iteration: {factorial_iteration_time:.6f} seconds""")

# TEST
test_cases = [5, 10, 25, 50, 99, 999, 9999]
for test_case in test_cases:
    test(test_case)

